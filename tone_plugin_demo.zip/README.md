# Tone Literacy Plugin by Erica Vega

## Setup (Vercel)
1. Clone this repo
2. Deploy on Vercel
3. Ensure `/api/classify-tone` is connected
4. Point your `plugin.json` and `openapi.yaml` URLs to your deployed Vercel domain
